package com.project.pojo;

public class ForgetPasswordPojo {
	private String email;
	private String pPassword;
	private String role;
private String cpwd;
	

	public String getCpwd() {
	return cpwd;
}

public void setCpwd(String cpwd) {
	this.cpwd = cpwd;
}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getpPassword() {
		return pPassword;
	}

	public void setpPassword(String pPassword) {
		this.pPassword = pPassword;
	}

	

}
